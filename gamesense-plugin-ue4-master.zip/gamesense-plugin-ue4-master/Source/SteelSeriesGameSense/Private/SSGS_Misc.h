/**
* Authors: sharkgoesmad
*
* Copyright (c) 2019 SteelSeries ApS. All Rights Reserved.
*/
#pragma once


#include "SSGS_Misc.generated.h"


USTRUCT()
struct FServerProps {

    GENERATED_BODY();

    UPROPERTY() FString address;

};
